// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "kk",
    d: "dd.MM.yyyy",
    D: "d MMMM yyyy \u0027ж.\u0027",
    t: "H:mm",
    T: "H:mm:ss",
    M: "d MMMM",
    Y: "MMMM yyyy",
    _am: "",
    _pm: "",
    _r: ",",
    _cr: ",",
    _t: " ",
    _ct: " ",
    _c: "\u0027\u0027#,0.00",
    _d: ["жс.","дс.","сс.","ср.","бс.","жм.","сн."],
    _D: ["жексені","дуйсенбі","сейсенбі","сәренбі","бейсенбі","жұма","сенбі"],
    _m: ["қаң.","ақп.","нау.","сәу.","мам.","мау.","шіл.","там.","қыр.","қаз.","қар.","желт.",""],
    _M: ["қаңтар","Ақпан","наурыз","сәуір","мамыр","маусым","шілде","тамыз","қыркүйек","қазан","қараша","желтоқсан",""]
});

