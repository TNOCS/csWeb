// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "uz-Latn-UZ",
    d: "dd/MM yyyy",
    D: "yyyy \u0027yil\u0027 d-MMMM",
    t: "HH:mm",
    T: "HH:mm:ss",
    M: "d-MMMM",
    Y: "MMMM yyyy",
    _am: "",
    _pm: "",
    _r: ",",
    _cr: ",",
    _t: " ",
    _ct: " ",
    _c: "#,0.00 \u0027soʼm\u0027",
    _d: ["Yaksh","Dush","Sesh","Chor","Pay","Cum","Shan"],
    _D: ["yakshanba","dushanba","seshanba","chorshanba","payshanba","cuma","shanba"],
    _m: ["Yanv","Fev","Mar","Apr","May","Iyun","Iyul","Avg","Sen","Okt","Noya","Dek",""],
    _M: ["Yanvar","Fevral","Mart","Aprel","May","Iyun","Iyul","Avgust","Sentyabr","Oktyabr","Noyabr","Dekabr",""]
});

