// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "sk-SK",
    d: "d. M. yyyy",
    D: "d. MMMM yyyy",
    t: "H:mm",
    T: "H:mm:ss",
    M: "dd MMMM",
    Y: "MMMM yyyy",
    _am: "dopoludnia",
    _pm: "popoludní",
    _r: ",",
    _cr: ",",
    _t: " ",
    _ct: " ",
    _c: "#,0.00 \u0027€\u0027",
    _d: ["ne","po","ut","st","št","pi","so"],
    _D: ["nedeľa","pondelok","utorok","streda","štvrtok","piatok","sobota"],
    _m: ["jan","feb","mar","apr","máj","jún","júl","aug","sep","okt","nov","dec",""],
    _M: ["január","február","marec","apríl","máj","jún","júl","august","september","október","november","december",""]
});

