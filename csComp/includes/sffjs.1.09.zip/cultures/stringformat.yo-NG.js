// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "yo-NG",
    d: "d/M/yyyy",
    D: "dddd, MMMM dd, yyyy",
    t: "h:mm tt",
    T: "h:mm:ss tt",
    M: "MMMM dd",
    Y: "MMMM, yyyy",
    _am: "Àárọ̀",
    _pm: "Ọ̀sán",
    _r: ",",
    _cr: ",",
    _t: ",",
    _ct: ",",
    _c: "#,0.00 \u0027₦\u0027",
    _d: ["Àìkú","Ajé","Ìsẹ́gun","Ọjọ́rú","Ọjọ́bọ","Ẹtì","Àbámẹ́ta"],
    _D: ["Ọjọ́ Àìkú","Ọjọ́ Ajé","Ọjọ́ Ìsẹ́gun","Ọjọ́rú","Ọjọ́bọ","Ọjọ́ Ẹtì","Ọjọ́ Àbámẹ́ta"],
    _m: ["Ṣẹ́rẹ́","Èrèlè","Ẹrẹ̀nà","Ìgbé","Ẹ̀bibi","Òkúdu","Agẹmọ","Ògún","Owewe","Ọ̀wàrà","Bélú","Ọ̀pẹ̀",""],
    _M: ["Oṣù Ṣẹ́rẹ́","Oṣù Èrèlè","Oṣù Ẹrẹ̀nà","Oṣù Ìgbé","Oṣù Ẹ̀bibi","Oṣù Òkúdu","Oṣù Agẹmọ","Oṣù Ògún","Oṣù Owewe","Oṣù Ọ̀wàrà","Oṣù Bélú","Oṣù Ọ̀pẹ̀",""]
});

